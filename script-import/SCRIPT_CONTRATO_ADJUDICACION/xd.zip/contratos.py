import odoorpc, csv

usuario = 'admin'
password = 'admin'
odoo = odoorpc.ODOO('sidur.galartec.com', port=80)
odoo.login('sidur2', usuario, password)


with open('contratos (7).csv', encoding="utf-8") as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        _search_contrato = odoo.env['proceso.elaboracion_contrato'].search([("num_contrato_sideop","=", row['num_contrato'])], limit=1)
        try:
            id_contrato = _search_contrato[0] #try
            _search_adjudicacion = odoo.env['proceso.adjudicacion_directa'].search([("numerocontrato","=", row['numero_contrato'])], limit=1)
            adjudicacion = _search_adjudicacion[0]
            tipo_contrato = 2 #2 es para adjudicacion
            contratos = odoo.env['proceso.elaboracion_contrato'].browse(id_contrato)
            contratos.write({
                'tipo_contrato': tipo_contrato,
                'adjudicacion': adjudicacion
            })

            adirecta_id = self.env['proceso.adjudicacion_directa'].browse(adjudicacion)
            print(adirecta_id)
            print('xd')
            for partidas in adirecta_id.programar_obra_adjudicacion:
                cont = cont + 1
                contratos.write({
                            'contrato_partida_adjudicacion': [[0, 0, {'obra': partidas.obra,
                                                                    'monto_partida': partidas.monto_partida,
                                                                    'iva_partida': partidas.iva_partida,
                                                                    'total_partida': partidas.total_partida,
                                                                    'nombre_partida': id_contrato,
                                                                    'p_id': cont
                                                                    }]]
                                })
            print(contratos)
        except:
            print("error")