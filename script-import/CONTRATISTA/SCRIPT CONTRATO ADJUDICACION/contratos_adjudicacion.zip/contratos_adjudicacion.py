import odoorpc, csv

usuario = 'admin'
password = 'admin'
odoo = odoorpc.ODOO('sidur.galartec.com', port=80)
odoo.login('sidur2', usuario, password)

with open('contratos (7).csv', encoding="utf-8") as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        if row['tipo_procedimiento'] == "AD":
            tipo_contrato = "2"  # 2 es para adjudicacion

            _search_contrato = odoo.env['proceso.elaboracion_contrato'].search_count(
                [("contrato", "=", row['numero_contrato'])])

            _search_contrato2 = odoo.env['proceso.elaboracion_contrato'].search(
                [("contrato", "=", row['numero_contrato'])])

            if _search_contrato == 0:
                id_contrato = _search_contrato2[0]
                _search_adjudicacion = odoo.env['proceso.adjudicacion_directa'].search(
                    [("numerocontrato", "=", row['referencia'])], limit=1)

                try:
                    adjudicacion = _search_adjudicacion[0]
                except:
                    print("error al buscar contrato" + str(row['num_contrato']))

                contratos = odoo.env['proceso.elaboracion_contrato'].browse(id_contrato)

                contratos.write({
                    'tipo_contrato': tipo_contrato,
                    'adjudicacion': adjudicacion
                })

                adirecta_id = odoo.env['proceso.adjudicacion_directa'].browse(adjudicacion)
                cont = 0
                cont2 = ""
                for partidas in adirecta_id.programar_obra_adjudicacion:
                    cont = cont + 1
                    cont2 = str(cont)
                    contratos.write({
                        'contrato_partida_adjudicacion': [[0, 0, {'id_contrato_sideop': row['num_contrato']
                                                                 ,'id_contratista': row['id_contratista']
                                                                 ,'id_partida': row['id_partida'],
                                                                  'obra': str(partidas.obra.id),
                                                                  'monto_partida': str(partidas.monto_partida),
                                                                  'nombre_partida': str(id_contrato),
                                                                  'id_contrato_relacion': str(adjudicacion),
                                                                  'p_id': str(cont)
                                                                  }]]
                    })
                    print(contratos)
            else:
                print('SE REPITIO CONTRATO')